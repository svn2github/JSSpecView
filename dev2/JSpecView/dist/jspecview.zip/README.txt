
.:.............................JSpecView.....................................:.

JSpecView is an open-source viewer for JCAMP-DX files written in Java and 
requires Sun JDK 1.5+   It was originally developed at:
The Department of Chemistry, University of the West Indies, Mona, JAMAICA.

Examples can be seen at jspecview.sourceforge.net

Usage questions/comments should be posted to jspecview-users@lists.sourceforge.net


Files list:
-----------
-COPYRIGHT.txt: Copyright information
-LICENSE.txt: GNU LGPL.
-README.txt: this file.

.:. applet .:.

-jspecview.jar: JSpecView Applet for use in web pages.
-Sjspecview.jar: self-signed JSpecView Applet for use in web pages.
-JSVCert.cer: certificate for signed applet
-JSVfunctions.js: JavaScript Library to simplify development of web pages.

.:. application .:.

-JSVApp.jar: Standalone application.

-pclanilIR.jdx for testing reading and writing IR files



